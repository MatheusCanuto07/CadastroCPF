<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=s, initial-scale=1.0">
    <link rel="stylesheet" href="./estili.css">
    <title>Document</title>
</head>
<body>
    
    
    
    
    <?php
    require_once "nav.php";
    require_once "funcoes.php";
    include "conexao.php";
    $flag = 1;
    $id=$nome = $sexo = $cep = $rua = $numero = $bairro = $cidade = $uf = "";
    
    if(isset($_POST['submit'])) {
        //receber e validar os dados do post
        
        $nome = trim($_POST['nome']);
        $sexo = trim($_POST['sexo']);
        $cep = trim($_POST['cep']);
        $rua = trim($_POST['rua']);
        $numero = trim($_POST['numero']);
        $bairro= trim($_POST['bairro']);
        $cidade = trim($_POST['cidade']);
        $uf = trim($_POST['uf']);
        
        //criar a query
        $query = "INSERT INTO cpf(nome,cep,rua,numero,bairro,cidade,uf,sexo) 
                    VALUES('$nome','$cep','$rua','$numero','$bairro','$cidade','$uf','$sexo')";
        //executar a query
        $resultado = $con->query($query);
        
        //validar o resultado
        if ($resultado) {
            echo "Dados inseridos com sucesso";
        } else {
            echo "Não foi possível inserir os dados! Erro: " . $con->error;
        }
        //fechar a conexão
        $con->close();
        
    } elseif (isset($_POST['alterar'])) {
        //receber e validar os dados do post
        
        $id = trim($_POST['id']);
        $nome = trim($_POST['nome']);
        $sexo = trim($_POST['sexo']);
        $cep = trim($_POST['cep']);
        $rua = trim($_POST['rua']);
        $numero = trim($_POST['numero']);
        $bairro= trim($_POST['bairro']);
        $cidade = trim($_POST['cidade']);
        $uf = trim($_POST['uf']);
        
        //criar a query
        $query = "UPDATE cpf SET nome = '$nome', sexo = '$sexo', cep = '$cep', rua = '$rua', numero = '$numero', bairro = '$bairro',
        cidade = '$cidade', uf = '$uf' WHERE id = $id";
        echo $query;
        //executar a query
        $resultado = $con->query($query);
        //validar o resultado
        if ($resultado) {
            echo "Dados atualizados com sucesso!";
            $nome = $sexo = $cep = $rua = $numero = $bairro = $cidade = $uf = "";
        } else {
            echo "Não foi possível atualizar os dados!";
        }
        //fechar a conexão
        $con->close();
    } else if(isset($_POST['pesquisar'])){
        $flag = 0;
        //receber e validar os dados do post
        $id = trim($_POST['id']);
        //criar a query
        $query = "SELECT * FROM cpf WHERE id = $id";
        //echo $query;
        //executar a query
        $resultado = $con-> query($query);
        //validar o resultado
        if ($resultado -> num_rows) {
            foreach ($resultado as $value) {
                foreach ($value as $key => $v) {
                    $$key = $v;
                }
            }
        } else {
            echo "Nenhum dado foi encontrado!";
            $flag = 1;
        }
        //fechar a conexão
        $con->close();
    } else if(isset($_POST['deletar'])){
        //receber e validar os dados do post
        $id = trim($_POST['id']);
        //criar a query
        $query = "DELETE FROM cpf WHERE id = $id";
        //executar a query
        $resultado = $con->query($query);
        //validar o resultado
        if ($resultado) {
            echo "Dados excluídos com sucesso!";
            $id = $nome = $logradouro = $cidade = $sexo = '';
        } else {
            echo "Não foi possível fazer a exclusão!";
        }
        //fechar a conexão
        $con->close();
    }
    ?>

    
    <div class="container">

        <form action="#" method="post">
            
            <label for="">Pesquisar</label>    
            <input type="text" placeholder="digite o seu id" name="id">
            <input type="submit" value="Pesquisar" name="pesquisar">
        </form>
        
        <form action="#" method="post">
            <label for="">Id</label>
            <input type="number" name="id" readonly value="<?= $id ?>">
            
            <label for="">Digite o seu nome</label>
            <input type="text" name="nome" type="text" id="nome" value="<?= $nome ?>">
            
            <br>
            <label for="">Sexo</label> <br>
            <input type="radio" name="sexo" id="sexo" value="masculino" checked>Masculino <br>
            <input type="radio" name="sexo" id="sexo" value="feminino">Feminino <br>
            <input type="radio" name="sexo" id="sexo" value="outro">Outro <br>
            
            <br>
            
            <label for="">Digite CEP</label>
        <input type="number" name="cep" id="cep" value="<?= $cep ?>">
        <button name="buscar">Buscar Cep</button>
        
        <?php isset($_POST['buscar']) ? $endereco = chama_endereco($_POST['cep']) : ''?>
        
        <label for="">Rua</label>
        <input type="text" value="<?= isset($_POST['buscar']) ? $endereco -> logradouro : $rua ?>" name="rua">
        
        <label for="">Número</label>
        <input type="number" name="numero" value="<?= $numero ?>">
        
        <label for="">Bairro</label>
        <input type="text" value="<?=isset($_POST['buscar']) ? $endereco -> bairro : $bairro ?>" name="bairro">
        
        <label for="">Cidade</label>
        <input type="text" value="<?=isset($_POST['buscar']) ? $endereco -> localidade : $cidade ?>" name="cidade">
        
        <label for="">UF</label>
        <input type="text" value="<?=isset($_POST['buscar']) ? $endereco -> uf : $uf ?>" name="uf">
        
        <input type="submit" value="Enviar" name="submit">
        <input type="submit" value="Alterar" name="alterar">
        <input type="submit" value="Deletar" name="deletar">
    </form>
    </div>
    <?php

require_once "footer.php";

?>
</body>
</html>